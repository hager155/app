============================================
Hot Coffee Mod V2 for GTA San Andreas
============================================  
http://www.gtagarage.com/mods/show.php?id=28
============================================
Author     : PatrickW (patrickw@gtagames.nl)
Co-Authors : Craig Kostelecky
             Hammer83
============================================
rating     : 18+
============================================

With this mod you will be able to unlock the uncensored 
interactive sex-games with your girlfriends in San Andreas.
Rockstar build all this stuff in the game, but decided to 
disable it in their final release for unknown reasons.
And now this mod enables these sex-games again, so now you 
can enjoy the full experience.

This package contains two versions of this mod:
* the quick action version, that will bring you quickly to the 
  action, but may spoil your gameplay.
* the gameplay friendly version, that will show you the action, 
  but doesn't influence the game-play. Now you must play the game 
  until you unlock a girlfriend and get her to go drink coffee with you.

A supplementary package is available, with a gameplay friendly version for the XBOX.
As the sacensor tool can't be used on that platform. 
    
Quick Action Version
--------------------  
This one has basicly the functionality of the first release: 
* You're dating every girlfriend from the beginning
* Girlfriends are always available for dates
* Girlfriends will have coffee with your after every date from the beginning.
* You will be able to see what they do when they say that they're drinking coffee.
* The "coffee drinking" is interactive, so you can proof yourself.
* you will still be able to play all the missions and side-games.

supplemented with:
* The girlfriends will now be completely nude during the coffee-drinking
* Craig Kostelecky's "Opened Up" mod is included, which means:
     - all barriers are removed
     - all areas accessible without 4 star penalty
     - most interiors accessible from the start (e.g. casino's)  

Install:
* Backup your data/script/main.scm and data/script/script.img files
* Replace the original main.scm and script.img files with the versions in this archive.
* Start a new game (old savefile will no longer work)
* Go to one of your girlfriends, date her en take her home


Gameplay Friendly version
-------------------------
After the first release of this mod, I got a lot of requests from people that wanted 
the uncensored action, but didn't want the other things that influenced the gameplay,
like being able to date all girls from the start.
I was gonna provide them with a version of the mod that did just that, but Hammer83 
came up with a much better idea: he created a tool ("sacensor.exe") that will let 
you switch just the "censored"-flag, either in a running game or in a savefile on disk.
This way you can still enjoy the action, even if you've already started a game and have made 
considerable progress and are not willing to start all over.
The only limitation is that this version will use the girlfriend-models that R* used for it, 
and not the fully nude ones from the Quick-action version.
Read Hammer83's sacensor_readme.txt for explanation of the usage of this tool.
Note: 
When using this tool, you should always have the original main.scm installed.
You can however install the script.img from the quick Action version, this will still keep the 
gameplay intact, but it will give you the full nude models.  


Credits
-------
Thanx to Barton Waterduck, for discovering the animations in the PS2 version.
Thanx to Hammer83, for creating the sacensor tool
Thanx to Craig Kostelecky, for having his mod included in this one.
Thanx to illspirit for pointing out the fully nude models
Thanx to www.gtagarage.com for hosting this mod at their brilliant site.
Greetings to the modding community at www.gtaforums.com
Greetings to the crew at the www.gtanet.com network
Greetings to the crew at www.gtagames.nl
Greetings to all NYCC members


History
-------
09 june 2005 - release of "hot coffee"
   * initial release
12 june 2005 - release of "hot coffee v2"
   * Included fully nude models
   * Included Craig kostelecky's "Opened up" mod
   * Included Hammer83's "sacensor" tool for gameplay friendly version
16 june 2005 - release of "hot coffee v2 for XBOX"
   * enable gameplay friendly version for the XBOX
17 june 2005 - release of "hot coffee v2.1"
   * fixed problem with triggering mission with the "quick action" version
   * removed limit of one date per day, date as often as you want.  
